// General Helper Function
function saveInventoryToLocalStorage(inventory) {
  localStorage.setItem('carInventory', JSON.stringify(inventory));
}

// ANALYTICS PAGE LOGIC
if (document.querySelector('.analytics-section')) {
  const carInventory = JSON.parse(localStorage.getItem('carInventory')) || [];

  const carNames = carInventory.map(car => car.name);
  const carYears = carInventory.map(car => car.year);
  const carPrices = carInventory.map(car => parseFloat(car.price.replace('$', '')));

  const totalInventoryValue = carPrices.reduce((a, b) => a + b, 0).toFixed(2);
  const averageCarPrice = (totalInventoryValue / carPrices.length).toFixed(2);
  const oldestCarYear = Math.min(...carYears);
  const newestCarYear = Math.max(...carYears);

  document.querySelector('.analytics-section').insertAdjacentHTML('beforeend', `
      <div class="summary-metrics">
          <h3>Total Inventory Value: $${totalInventoryValue}</h3>
          <h3>Average Car Price: $${averageCarPrice}</h3>
          <h3>Oldest Car Year: ${oldestCarYear}</h3>
          <h3>Newest Car Year: ${newestCarYear}</h3>
      </div>
  `);

  const carData = {
      labels: carNames,
      datasets: [
          {
              label: "Model Year",
              data: carYears,
              backgroundColor: "rgba(255, 99, 132, 0.2)",
              borderColor: "rgba(255, 99, 132, 1)",
              borderWidth: 1,
              yAxisID: 'yYear'
          },
          {
              label: "Price (USD)",
              data: carPrices,
              backgroundColor: "rgba(54, 162, 235, 0.2)",
              borderColor: "rgba(54, 162, 235, 1)",
              borderWidth: 1,
              yAxisID: 'yPrice'
          }
      ]
  };

  const config = {
      type: 'bar',
      data: carData,
      options: {
          responsive: true,
          plugins: {
              legend: { position: 'top' },
              tooltip: { enabled: true }
          },
          scales: {
              yYear: {
                  type: 'linear',
                  position: 'left',
                  beginAtZero: false,
                  title: {
                      display: true,
                      text: 'Model Year'
                  }
              },
              yPrice: {
                  type: 'linear',
                  position: 'right',
                  beginAtZero: true,
                  title: {
                      display: true,
                      text: 'Price (USD)'
                  }
              }
          }
      }
  };

  new Chart(document.getElementById('carPerformanceChart'), config);
}

// MANAGE INVENTORY PAGE LOGIC
if (document.querySelector('#carTable')) {
  let carInventory = JSON.parse(localStorage.getItem('carInventory')) || [];
  let editIndex = null;

  document.getElementById('submitButton').addEventListener('click', addOrUpdateCar);
  displayCars();

  function addOrUpdateCar() {
      const name = document.getElementById('carName').value.trim();
      const model = document.getElementById('carModel').value.trim();
      const year = parseInt(document.getElementById('carYear').value, 10);
      const price = parseFloat(document.getElementById('carPrice').value);

      //Validation
      if (!name || !model || isNaN(year) || isNaN(price) || year === 0 || price === 0) {
          alert("All fields must be filled out correctly.");
          return;
      }

      const currentYear = new Date().getFullYear();
      if (year < 1886 || year > currentYear) {
          alert(`Year must be between 1886 and ${currentYear}.`);
          return;
      }

      if (price <= 0) {
          alert("Price must be a positive number.");
          return;
      }

      const formattedPrice = `$${price.toFixed(2)}`;

      // Check if we are editing an existing car
      if (editIndex !== null) {
          carInventory[editIndex] = { name, model, year, price: formattedPrice };
          editIndex = null;
          document.getElementById('formHeading').textContent = "Add a New Car";
          document.getElementById('submitButton').textContent = "Add Car";
      } else {
          carInventory.push({ name, model, year, price: formattedPrice });
      }

      displayCars();
      saveInventoryToLocalStorage(carInventory); // Save data after each operation
      document.getElementById('carForm').reset(); // Clear form fields
  }

  function displayCars() {
      const tableBody = document.querySelector('#carTable tbody');
      tableBody.innerHTML = ''; // Clear existing rows

      carInventory.forEach((car, index) => {
          const row = `<tr>
              <td>${car.name}</td>
              <td>${car.model}</td>
              <td>${car.year}</td>
              <td>${car.price}</td>
              <td>
                  <button onclick="editCar(${index})">Edit</button>
                  <button onclick="deleteCar(${index})">Delete</button>
              </td>
          </tr>`;
          tableBody.insertAdjacentHTML('beforeend', row);
      });
  }

  function editCar(index) {
      const car = carInventory[index];
      document.getElementById('carName').value = car.name;
      document.getElementById('carModel').value = car.model;
      document.getElementById('carYear').value = car.year;
      document.getElementById('carPrice').value = parseFloat(car.price.replace('$', ''));
      editIndex = index;

      document.getElementById('formHeading').textContent = "Modify Inventory";
      document.getElementById('submitButton').textContent = "Modify";
  }

  function deleteCar(index) {
      carInventory.splice(index, 1);
      displayCars();
      saveInventoryToLocalStorage(carInventory); // Save data after deletion
  }
}
